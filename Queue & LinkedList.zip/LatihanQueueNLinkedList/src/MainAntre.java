
public class MainAntre {
    public static void main(String[] args) {
        
        Antre antrian = new Antre(5);
        
        // insert data
        antrian.insert("Gallardo");
        antrian.insert("Cabriolet");
        antrian.insert("Veyron");
        antrian.insert("Chiron");
        antrian.insert("Gran Turismo");
        antrian.insert("Huracan");
        antrian.insert("Ford GT");
        
        // tampilkan antrian dan mengosongkannya
        System.out.println("===============");
        System.out.println("Isi Antrian");
        System.out.println("===============");
        
        while ( !antrian.empty() ) {
            String mobil = antrian.remove();
            System.out.println(mobil);
        }
        
        System.out.println("===============");
        
    }
}

class Antre{
    
    String[] data;
    int depan, belakang, maksElm;
    
    // Constructor
    Antre(int ukuran){
        depan = 0;
        belakang = 0;
        maksElm = ukuran;
        data = new String[maksElm];
    }
    
    // memasukan data
    void insert(String data){
        int posisiBelakang, isFull = maksElm -1;
        
        // geser data belakang ke posisi berikutnya
        if ( belakang == isFull ) {
            posisiBelakang = 0;
        } else {
            posisiBelakang = belakang + 1;
        }
        
        // belakang == depan ?
        if ( posisiBelakang == depan ) {
            System.out.println("Antrian Penuh.");
            System.out.println(data + " tidak dapat dimasukan.");
        } else {
            belakang = posisiBelakang;
            
            // input data
            this.data[belakang] = data;
        }
    }
    
    String remove(){
        if (empty()) {
            System.out.println("Antrian Kosong.");
            depan = 0;
            return "";
        } else {
            depan = depan + 1;
        }
        return data[depan];
    }
    
    boolean empty(){
        if ( depan == belakang ) {
            return true;
        } else {
            return false;
        }
    }
    
}
