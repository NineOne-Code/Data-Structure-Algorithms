import java.util.LinkedList;
public class MainLinkedList {
    public static void main(String[] args) {
        LinkedList<Simpul> karesidenanBesuki = new LinkedList<Simpul>();
        Simpul simpul;
        
        // masukan data
        karesidenanBesuki.push(new Simpul("BWS", "Bondowoso"));
        karesidenanBesuki.push(new Simpul("STB", "Situbondo"));
        karesidenanBesuki.push(new Simpul("JBR", "Jember"));
        karesidenanBesuki.push(new Simpul("BWI", "Banyuwangi"));
        karesidenanBesuki.push(new Simpul("SBY", "Surabaya"));
        
        System.out.println("Daftar Kabupaten Karesidenan Besuki: ");
        for (int i = 0; i < karesidenanBesuki.size(); i++) {
            simpul = karesidenanBesuki.get(i);
            simpul.display();
        }
        
        // hapus data
        hapus(karesidenanBesuki, "SBY");
        
        // stelah SBY dihapus
        System.out.println("\n\nDaftar Kabupaten Karesidenan Besuki: ");
        for (int i = 0; i < karesidenanBesuki.size(); i++) {
            simpul = karesidenanBesuki.get(i);
            simpul.display();
        }
        
        // cari data
        String dicari = "BWS";
        System.out.println("\nPencarian " + dicari);
        Simpul posisiData = cari(karesidenanBesuki, dicari);
        if ( posisiData == null ) {
            System.out.println(dicari + " tidak ditemukan.");
        } else {
            System.out.println("Hasil Pencarian data " + dicari + ": ");
            posisiData.display();
        }
        
        dicari = "SBY";
        System.out.println("\nPencarian " + dicari);
        posisiData = cari(karesidenanBesuki, dicari);
        if ( posisiData == null ) {
            System.out.println(dicari + " tidak ditemukan.");
        } else {
            System.out.println("Hasil Pencarian data " + dicari + ": ");
            posisiData.display();
        }
        
    }
    
    // Mencari data
    public static Simpul cari(LinkedList<Simpul> daftar, String data){
        int posisi = -1;
        
        for (int i = 0; i < daftar.size(); i++) {
            Simpul simpul = daftar.get(i);
            if ( simpul.kode.compareToIgnoreCase(data) == 0 ) {
                posisi = i;
                break;
            }
        }
        
        if ( posisi == -1 ) {
            return null;
        } else {
            return daftar.get(posisi);
        }
        
    }
    
    // Menghapus Data
    public static void hapus (LinkedList<Simpul> daftar, String data){
        int posisi = -1;
        
        for (int i = 0; i < daftar.size(); i++) {
            Simpul simpul = daftar.get(i);
            if ( simpul.kode.compareToIgnoreCase(data) == 0 ) {
                posisi = i;
                break;
            }
        }
        
        if ( posisi != -1 ) {
            daftar.remove(posisi);
        } else {
            System.out.println(data + " tidak ditemukan.");
        }
        
    }
    
}

class Simpul{
    public String kode;
    public String kota;
    
    public Simpul(String xKode, String xKota){
        kode = xKode;
        kota = xKota;
    }
    
    public void display(){
        System.out.println(kode + ": " + kota);
    }
}
